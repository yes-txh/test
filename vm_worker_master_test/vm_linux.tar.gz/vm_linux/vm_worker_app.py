#-*- coding:utf8 -*-
import sys
import os
import threading
import subprocess
import time
import logging

sys.path.append('./gen')

# 导入thrift定义的模块
from gen.vm_worker import VMWorker  # vm service
from gen.vm_worker.ttypes import *  # vm struct

from gen_worker.worker.ttypes import * # worker struct

# 日志信息存入vm_worker.log
logger = logging.getLogger()
handler=logging.FileHandler("vm_worker.log")
formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.NOTSET)


def IntervalRunWorker(id, name, source, exe, argument, interval):
        #周期启动应用程序
        count = 0
        while(True):
            count = count + 1
            print count #记录应用轮询次数
            try:
                    state_file = open(source + '/daemon', 'r')
                    content = state_file.read()
                    state_file.close()
                    if content == "stopped":
                        print "stop ok"
                        return True
            except OSError, e:
		logger.error(e)
                continue
            except IOError, e:
		logger.error(e)
                continue
            exe_path = source + "/" + exe
            cmd ='sh'+' '+ exe_path + ' ' + argument
            interval_p = subprocess.Popen(cmd, shell = True, cwd = source)
            rtn = interval_p.wait()
	    if rtn != 0:
		vmworker_app = VMWorkerApp()
		vmworker_app.SetHbAppState(id, name, AppState.APP_FAILED, 2)	
		logger.error('app run error '+rtn)    
		continue
            time.sleep(interval)

class VMWorkerApp:
    """
    虚拟机应用类
    """
    global vm_hbapp_info
    vm_hbapp_info = VM_HbAppInfo()
    vm_hbapp_info.id = 0
    vm_hbapp_info.app_name = " "
    vm_hbapp_info.state = AppState.APP_NOTFOUND
    vm_hbapp_info.error_id = 0
    vm_hbapp_info.app_install = False
    global vm_app_info
    vm_app_info = VM_AppInfo()	

    def __init__(self):        
	pass

    def SetHbAppState(self, id, name, state, error_id):
	vm_hbapp_info.id = id
	vm_hbapp_info.name = name
	vm_hbapp_info.state = state
	vm_hbapp_info.error_id = error_id
	return True
    
    def GetHbAppState(self):
  	return vm_hbapp_info

    def SetAppInfo(self,app_info):
	vm_app_info.id = app_info.id
	vm_app_info.name = app_info.name
	vm_app_info.source = app_info.source
	#vm_app_info.install_dir = app_info.install_dir
	vm_app_info.exe = app_info.exe
	vm_app_info.argument = app_info.argument
	return True

    def AppRunWorker(self, id, name, source, exe, argument, run_type, interval):
	self.SetHbAppState(id, name, AppState.APP_ONLINE, 0)
        if run_type == 'normal':
            exe_path = source + "/" + exe
	    if not os.path.exists(exe_path):
		self.SetHbAppState(id, name, AppState.APP_FAILED, 1)
		logger.error('can not found app file')
		return False
            cmd ='sh'+' '+ exe_path + ' ' + argument
            p = subprocess.Popen(cmd, shell = True, cwd = source)
            rtn = p.wait()
            ## 监控应用进程，异常则做相应的处理
	    if rtn != 0:
		self.SetHbAppState(id, name, AppState.APP_FAILED, 2)
		logger.error(name+' app run error '+rtn)
		return False
            ###
	    self.SetHbAppState(id, name, AppState.APP_FINISHED, 0)
            return True

        elif run_type == 'daemon':
            print "daemon"
	    exe_path = source + "/" + exe
	    if not os.path.exists(exe_path):
                self.SetHbAppState(id, name, AppState.APP_FAILED, 1)
		logger.error('can not found app file')
                return False
            try:
                #写个文件表示应用正在运行
                state_file = open(source + '/daemon','w')
                state_file.write('running')
                state_file.close()
            except OSError, e:
                logger.error(e)
                return False
            except IOError, e:
                logger.error(e)
                return False
            #启动周期运行应用线程
            interval_run_worker = threading.Thread(target = IntervalRunWorker, args = (id, name, source, exe, argument, interval))
            interval_run_worker.start()
            #守护周期运行线程
	    while(True):
                if not interval_run_worker.is_alive():
                    try:
                        state_file = open(source + '/daemon', 'r')
                        content = state_file.read()
                        state_file.close()
                        if content == 'stopped':
                            return True
                    except OSError, e:
                        logger.error(e)
                        #return False
                        continue
                    except IOError, e:
                        logger.error(e)
                        #return False
                        continue
                    interval_run_worker = threading.Thread(target = IntervalRunWorker, args = (id, name, source, exe, argument, interval))
                    interval_run_worker.start()
                time.sleep(interval)
            return True

        else:
            print "unknown type" + run_type
	    logger.error('unknown type '+runtype)
            return False

    def AppStopWorker4Daemon(self, id, args):
	if id != vm_app_info.id:
                self.SetHbAppState(id, " ", AppState.APP_FAILED, 3)
                logger.error("the id can not found app")
                return False
	name = vm_app_info.name
	source = vm_app_info.source
        try:
                #写个文件表示应用正在运行
                state_file = open(source + '/daemon','w')
                state_file.write('stopped')
                state_file.close()
        except OSError, e:
                logger.error(e)
                return False
        except IOError, e:
                logger.error(e)
                return False
        print"stop app ok"
	self.SetHbAppState(id, name, AppState.APP_FINISHED, 0)
        return True

    def AppStopWorker(id, stop):
	if id != vm_app_info.id:
		self.SetHbAppState(id, " ", AppState.APP_FAILED, 3)
		logger.error("the id can not found app")
		return False
	name = vm_app_info.name
        source = vm_app_info.source
	argument = vm_app_info.argument
        exe_path = source + "/" + stop
        cmd ='sh'+' '+ exe_path + ' ' + argument
        p = subprocess.Popen(cmd, shell = True, cwd = source)
        rtn = p.wait()
	if rtn != 0:
		self.SetHbAppState(id, name, AppState.APP_FAILED, 2)
		logger.error(name+' app run error '+rtn)
                return False
	self.SetHbAppState(id, name, AppState.APP_FINISHED, 0)
	print"stop app ok"
        return True

